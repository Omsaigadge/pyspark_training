set echo on
alter system flush shared_pool;
grant advisor to sh;
connect sh/sh;

SELECT c.cust_last_name, sum(s.amount_sold) AS dollars,
sum(s.quantity_sold) as quantity
FROM sales s , customers c, products p
WHERE c.cust_id = s.cust_id
AND s.prod_id = p.prod_id
AND c.cust_state_province IN ('Dublin','Galway')
GROUP BY c.cust_last_name;


SELECT c.cust_id, SUM(amount_sold) AS dollar_sales 
  FROM sales s, customers c WHERE s.cust_id= c.cust_id  GROUP BY c.cust_id;

select sum(unit_cost) from costs group by prod_id;

