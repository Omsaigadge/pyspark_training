/* statement 1 */

SELECT cust_first_name, cust_last_name, cust_credit_limit
FROM test_customers
WHERE cust_credit_limit =1500;
SELECT cust_first_name, cust_last_name, cust_credit_limit
FROM test_customers
WHERE cust_credit_limit =3000;
SELECT cust_first_name, cust_last_name, cust_credit_limit
FROM test_customers
WHERE cust_credit_limit =11000;
SELECT cust_first_name, cust_last_name, cust_credit_limit
FROM test_customers
WHERE cust_credit_limit =5000;
SELECT cust_first_name, cust_last_name, cust_credit_limit
FROM test_customers
WHERE cust_credit_limit =1000;
SELECT cust_first_name, cust_last_name, cust_credit_limit
FROM test_customers
WHERE cust_credit_limit =9000;
SELECT cust_first_name, cust_last_name, cust_credit_limit
FROM test_customers
WHERE cust_credit_limit =10000;
SELECT cust_first_name, cust_last_name, cust_credit_limit
FROM test_customers
WHERE cust_credit_limit =15000;
SELECT cust_first_name, cust_last_name, cust_credit_limit
FROM test_customers
WHERE cust_credit_limit =11000;
SELECT cust_first_name, cust_last_name, cust_credit_limit
FROM test_customers
WHERE cust_credit_limit =7000;


/* statement 2 */

SELECT MAX(cust_credit_limit)
FROM test_customers
WHERE cust_city ='Paris';

/* statement 3 */

SELECT c.cust_gender, c.cust_marital_status, SUM(quantity_sold), 
SUM(amount_sold) 
FROM test_promotions p,test_sales s,test_customers c 
WHERE p.promo_id=s.promo_id 
  AND promo_name='NO PROMOTION #' 
  AND s.cust_id=c.cust_id 
GROUP BY c.CUST_GENDER, C.CUST_MARITAL_STATUS;

/* statement 4 */

 SELECT count(*)  FROM (
      SELECT PROMO_CATEGORY, SUM(PROMO_COST)
      FROM test_promotions
      WHERE PROMO_NAME <> 'NO PROMOTION'
      GROUP BY PROMO_CATEGORY) ;

/* statement 5 */

SELECT  count(co.country_name) 
      FROM test_countries co,test_customers cu
      WHERE co.country_id=cu.country_id
        AND cu.cust_credit_limit = 
           (SELECT max(cust_credit_limit)
            FROM test_customers
            WHERE cust_year_of_birth = '1990')
        AND cu.cust_year_of_birth = '1990';

/* statement 6 */

 SELECT cust_id, SUM(quantity_sold)
      FROM test_sales
      WHERE prod_id = 30
      GROUP BY cust_id
      ORDER BY 2;

/* statement 7 */


SELECT cust_last_name, cust_first_name
FROM test_customers
WHERE UPPER(cust_last_name)like  'K%';


/* statement 8 */

SELECT cust_last_name, s.country_name
FROM test_customers c, test_countries s
WHERE c.country_id = s.country_id 
AND SUBSTR(TO_CHAR(s.country_id), 1, 1) = '1';


