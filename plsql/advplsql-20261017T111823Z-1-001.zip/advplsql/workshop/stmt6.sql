 SELECT cust_id, SUM(quantity_sold)
      FROM sales
      WHERE prod_id = 30
      GROUP BY cust_id
      ORDER BY 2;

