EXPLAIN PLAN FOR
SELECT cust_id                           -- ws01_05.sql
FROM   customers
WHERE  cust_credit_limit = 30000/2
/
