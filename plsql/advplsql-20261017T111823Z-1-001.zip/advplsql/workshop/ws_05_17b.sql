SELECT   week_ending_day
,        prod_subcategory
,        dollars
FROM     costs_per_year_mv
WHERE    calendar_year = '1999'
AND      dollars > 10000;

