SELECT cust_first_name                       -- ws01_01a.sql
,      cust_last_name
FROM   customers
WHERE  cust_id <> 1030
/
