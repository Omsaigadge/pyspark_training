EXPLAIN PLAN FOR
SELECT --+ INDEX(c)                     
       c.cust_id
FROM   customers c
WHERE  c.cust_email IS NOT NULL
/
