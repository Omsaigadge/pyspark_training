CREATE OR REPLACE VIEW cust_inc_view AS
SELECT cust_id, cust_credit_limit, cust_last_name, cust_income_level
FROM customers 
WHERE cust_income_level LIKE 'B%'
/
