EXPLAIN PLAN FOR
SELECT * FROM sales_temp, dual
/