INSERT INTO sales_temp SELECT cust_id, amount_sold
FROM sales WHERE rownum <= 100000
/
