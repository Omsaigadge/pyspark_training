EXPLAIN PLAN FOR
SELECT cust_first_name           
,      cust_last_name
,      cust_credit_limit
FROM   customers
ORDER  BY cust_credit_limit;
/