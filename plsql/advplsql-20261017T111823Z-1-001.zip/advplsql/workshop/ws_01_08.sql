EXPLAIN PLAN FOR
SELECT cust_last_name                        
FROM   customers
WHERE  cust_last_name LIKE 'S%'
/
