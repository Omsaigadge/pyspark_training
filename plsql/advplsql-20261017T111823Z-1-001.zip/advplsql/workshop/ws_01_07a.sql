EXPLAIN PLAN FOR
SELECT cust_id                           -- ws01_07.sql
FROM   customers
WHERE  UPPER(cust_last_name) = 'KING'
/
