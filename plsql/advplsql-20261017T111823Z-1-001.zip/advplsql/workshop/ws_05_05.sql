SELECT prod_name                       
,      prod_status
,       date_sold
FROM   v_sales_detail
WHERE  prod_id  IN (4680, 15180)
/
