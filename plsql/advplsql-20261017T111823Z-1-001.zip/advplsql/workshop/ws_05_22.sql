
set echo on

rem try the MV with an intended typo in the query:

SELECT /*+ REWRITE_OR_ERROR */
       prod_id
,      avg(quantity_sold)
FROM   sales
WHERE  channel_id = 9
GROUP  BY prod_id;

