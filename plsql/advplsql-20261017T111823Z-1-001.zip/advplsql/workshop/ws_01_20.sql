EXPLAIN PLAN FOR
SELECT distinct cust_city                
FROM   customers
/
