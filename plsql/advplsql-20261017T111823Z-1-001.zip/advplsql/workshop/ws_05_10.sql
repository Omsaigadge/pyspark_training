       

 SELECT country_name   avg_credit               
   FROM v_avg_credit_limit a, countries c
   WHERE a.country_id = c.country_id
   AND country_region = 'Europe'
/
