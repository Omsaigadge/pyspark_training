SELECT cust_first_name                       
,      cust_last_name
FROM   customers
WHERE  cust_id = 1030
/
