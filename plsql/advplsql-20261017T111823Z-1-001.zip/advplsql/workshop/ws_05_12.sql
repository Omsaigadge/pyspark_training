SELECT calendar_month_number      
,      calendar_month_name
,      calendar_quarter_desc
,      calendar_quarter_number
FROM   v_99_00_times
WHERE  calendar_year = '1999'
/
