EXPLAIN PLAN FOR
SELECT cust_id                           
FROM   customers
WHERE  cust_last_name =  INITCAP('KING')
/
