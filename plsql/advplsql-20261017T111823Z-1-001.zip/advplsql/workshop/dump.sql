 SElECT *
  FROM   v$parameter
 WHERE  name LIKE '%dump%';
