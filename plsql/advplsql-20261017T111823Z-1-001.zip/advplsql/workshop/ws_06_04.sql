SELECT country_name        
FROM   countries co
WHERE  EXISTS (SELECT /*+ &hint */ 'x'
               FROM    customers c
              WHERE  co.country_id = c.country_id
              and c.cust_credit_limit < 2000)
/