SELECT /*+ AND_EQUAL (c &index_name1, &index_name2) */
      c.*                  -- ws06_07.sql
FROM   customers c
WHERE  cust_gender   = 'M'
AND    cust_postal_code = 40804
AND   cust_credit_limit = 10000
/
