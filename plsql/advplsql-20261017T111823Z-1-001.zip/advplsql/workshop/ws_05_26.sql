column message format a40 word

SELECT message
,      original_cost, rewritten_cost
FROM   rewrite_table;
