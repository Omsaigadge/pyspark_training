REM  
REM  script ATONX.SQL
REM  =====================================
SET AUTOTRACE ON EXPLAIN
