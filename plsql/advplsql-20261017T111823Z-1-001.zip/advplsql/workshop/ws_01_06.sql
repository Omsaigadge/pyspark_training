EXPLAIN PLAN FOR
SELECT cust_id                           -- ws01_06.sql
FROM   customers
WHERE  SUBSTR(cust_last_name,1,1) = 'S'
/
