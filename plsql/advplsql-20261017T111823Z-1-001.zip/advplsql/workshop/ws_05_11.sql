CREATE OR REPLACE VIEW v_99_00_times   
AS
SELECT *
FROM times
WHERE calendar_year = '1999'
UNION
SELECT *
FROM times
WHERE calendar_year = '2000'
/
