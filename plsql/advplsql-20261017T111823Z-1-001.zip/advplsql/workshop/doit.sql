
drop index CUST_COUNTRY_ID_IDX;
