accept table_name  -
       prompt 'on which table : '






SELECT index_name name, num_rows n_r,  
last_analyzed l_a, distinct_keys d_k, 
leaf_blocks l_b,   avg_leaf_blocks_per_key a_l,join_index j_I
FROM user_indexes 
WHERE table_name = upper('&table_name');




undef table_name