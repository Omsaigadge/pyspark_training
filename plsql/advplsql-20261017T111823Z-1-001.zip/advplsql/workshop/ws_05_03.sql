SELECT pr.prod_name                          
,      pr.prod_status
,      to_char(sa.time_id, 'YYYY-MON-DD') date_sold
FROM   sales sa
,      products pr
WHERE  pr.prod_id = sa.prod_id(+)
AND    sa.prod_id = 15180
/
