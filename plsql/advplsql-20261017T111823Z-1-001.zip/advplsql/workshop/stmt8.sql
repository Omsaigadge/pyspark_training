select cust_last_name, s.country_name
from test_customers c, test_countries s
where c.country_id = s.country_id 
and substr(to_char(s.country_id), 1, 1) = '1';
