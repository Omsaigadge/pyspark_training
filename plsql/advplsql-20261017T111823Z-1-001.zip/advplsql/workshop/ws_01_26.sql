EXPLAIN PLAN FOR
SELECT cust_city                              
,      avg(cust_credit_limit)
FROM   customers
WHERE  cust_city = 'Paris'
GROUP  BY cust_city
/
