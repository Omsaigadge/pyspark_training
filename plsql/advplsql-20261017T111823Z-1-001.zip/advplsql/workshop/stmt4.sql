SELECT COUNT(*)  FROM (
      SELECT promo_category, SUM(promo_cost)
      FROM test_promotions
      WHERE promo_name <> 'NO PROMOTION'
      GROUP BY promo_category) ;

