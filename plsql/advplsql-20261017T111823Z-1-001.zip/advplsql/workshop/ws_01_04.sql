EXPLAIN PLAN FOR
SELECT cust_id                           -- ws01_04.sql
FROM   customers
WHERE  cust_credit_limit*1.10 = 11000
/
