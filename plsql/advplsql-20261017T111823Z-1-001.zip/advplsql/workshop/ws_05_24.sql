

Explain plan for
SELECT prod_id
,      avg(amount_sold)
FROM   sales
WHERE  channel_id = 9
GROUP  BY prod_id;
