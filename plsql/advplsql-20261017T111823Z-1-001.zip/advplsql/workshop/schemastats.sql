SELECT last_analyzed analyzed, sample_size, monitoring,
        table_name
FROM user_tables;
