REM   
REM   script ALLROWS.SQL
REM   =====================================
alter session set optimizer_mode = all_rows
/