UPDATE CUSTOMERS                 
SET cust_email = NULL
WHERE cust_main_phone_number LIKE '_7%'
OR cust_main_phone_number LIKE '2%'
OR cust_main_phone_number LIKE '__3%'
OR cust_main_phone_number LIKE '___6%'
/
