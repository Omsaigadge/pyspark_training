SELECT cust_first_name                       -- ws01_03.sql
,      cust_last_name
FROM   customers
WHERE  cust_id between 70 and 80
/
