EXPLAIN PLAN FOR 
SELECT cust_last_name FROM customers 
WHERE cust_city = 'Paris'  
MINUS
SELECT cust_last_name FROM customers 
WHERE cust_credit_limit > 10000
/
