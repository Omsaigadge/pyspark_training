SELECT c.*                  
FROM   customers c
WHERE  c.country_id IN (52790,52771)
/
