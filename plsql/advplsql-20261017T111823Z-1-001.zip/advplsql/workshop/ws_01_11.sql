EXPLAIN PLAN FOR
SELECT cust_id                         
FROM   customers
WHERE  cust_email IS NOT NULL
/
