SELECT  count(co.country_name) 
      FROM test_countries co,test_customers cu
      WHERE co.country_id=cu.country_id
        AND cu.cust_credit_limit = 
           (SELECT max(cust_credit_limit)
            FROM test_customers
            WHERE cust_year_of_birth = '1990')
        AND cu.cust_year_of_birth = '1990';

