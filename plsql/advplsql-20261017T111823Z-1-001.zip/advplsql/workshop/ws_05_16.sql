SELECT p.prod_id, p.prod_name, t.time_id, 
        s.channel_id, s.promo_id, s.cust_id,
           t.week_ending_day, s.amount_sold
  FROM   sales s, products p, times t
  WHERE  s.time_id=t.time_id
 AND    s.prod_id = p.prod_id                  
