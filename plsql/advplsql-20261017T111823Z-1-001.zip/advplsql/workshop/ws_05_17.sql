rem 
rem ===============================
set termout off feedback off
drop materialized view fweek_pscat_costs_mv;

set feedback on termout on

Drop materialized view costs_per_year_mv;

CREATE MATERIALIZED VIEW
costs_per_year_mv
ENABLE QUERY REWRITE
AS
SELECT   t.week_ending_day
,        t.calendar_year
,        p.prod_subcategory
,        sum(c.unit_cost) AS dollars
FROM     costs c
,        times t
,        products p
WHERE    c.time_id = t.time_id
AND      c.prod_id = p.prod_id
GROUP BY t.week_ending_day
,        t.calendar_year
,        p.prod_subcategory
/


create index mvi_dollars on costs_per_year_mv(dollars);

create index mvi_calendar_year  on  costs_per_year_mv(calendar_year);

Exec DBMS_STATS.GATHER_TABLE_STATS ('sh', 'costs_per_year_mv');

