EXPLAIN PLAN FOR
SELECT MAX(cust_credit_limit*2)          
FROM   customers
/
