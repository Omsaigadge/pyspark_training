SELECT * FROM products WHERE prod_status LIKE 'available, on stock'
/
