REM  
REM  script ATTO.SQL
REM  =====================================
set autotrace traceonly