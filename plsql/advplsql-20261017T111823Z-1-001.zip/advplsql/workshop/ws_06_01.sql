SELECT c.cust_last_name           
FROM   customers c
WHERE  c.country_id = 52790
AND    c.cust_id NOT IN (
                         select s.cust_id
                         from sales s)
/
