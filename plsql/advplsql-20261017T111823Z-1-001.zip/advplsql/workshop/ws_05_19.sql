EXEC DBMS_MVIEW.EXPLAIN_MVIEW ('costs_per_year_mv', '678');
