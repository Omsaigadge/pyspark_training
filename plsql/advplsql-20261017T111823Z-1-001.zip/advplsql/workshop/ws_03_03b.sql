
col index_name format a10
col table_name format a10

SELECT * FROM v$object_usage
/
