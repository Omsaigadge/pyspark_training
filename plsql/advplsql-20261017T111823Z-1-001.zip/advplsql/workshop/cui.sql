REM    SQL Tuning Workshop
REM    script CUI.SQL (create unique index)
REM    prompts for input; index name generated
REM    =======================================
accept TABLE_NAME  prompt "     on which table    : "
accept COLUMN_NAME prompt "     on which column(s): "\
set    termout off
store  set saved_settings replace
set    heading off feedback off verify off
set    autotrace off termout on
SELECT 'creating unique index'
,      SUBSTR('ui_&TABLE_NAME._' ||
               TRANSLATE(REPLACE('&COLUMN_NAME', ' ', '')
                        , ',', '_')
             , 1, 30) dummy
,      '...'
from    dual
/
CREATE UNIQUE INDEX &INDEX_NAME ON &TABLE_NAME(&COLUMN_NAME)
/
@saved_settings
set    termout on
undef  INDEX_NAME
undef  TABLE_NAME
undef  COLUMN_NAME
