SELECT /*+ INDEX_FFS(e) */  
      e.last_name
,     e.first_name
FROM   hr.employees e
/
