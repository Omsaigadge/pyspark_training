set feedback off


SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_CURSOR('your sql_id here'));

set feedback on
