SELECT prod_name                       
,      prod_status
,       date_sold
FROM   v_sales_detail
WHERE  prod_id = 15180
/
