--this script flushes the shared pool

alter system flush shared_pool
/
