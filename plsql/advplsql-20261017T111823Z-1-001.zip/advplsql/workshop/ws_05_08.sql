SELECT  cust_last_name FROM cust_inc_view
 WHERE cust_credit_limit = 1500
 OR cust_id =  499290       
/
