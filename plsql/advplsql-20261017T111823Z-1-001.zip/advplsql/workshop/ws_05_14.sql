SELECT *                               
FROM join_sales_time_product_mv
WHERE amount_sold = 2000
/
