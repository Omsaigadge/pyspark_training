REM  
REM  script ATOFF.SQLREM  =====================================
SET AUTOTRACE OFF
