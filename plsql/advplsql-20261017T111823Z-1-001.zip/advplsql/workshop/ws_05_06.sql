SELECT v.prod_name                    
,      v.prod_status
,      v.date_sold
FROM   v_sales_detail v
WHERE  v.prod_name = 'Sunburst Dress'
/
