SELECT cust_first_name                       -- ws01_02.sql
,      cust_last_name
FROM   customers
WHERE  cust_id < 10
/
