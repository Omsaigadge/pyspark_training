
set echo on


EXECUTE DBMS_MVIEW.EXPLAIN_REWRITE -
( 'SELECT prod_id                  -
   ,      avg(amount_sold)         -
   FROM   sales                    -
   WHERE  channel_id = 9           -
   GROUP  BY prod_id'              -
, 'SH.MY_MV'                       -
, 'Practice 05-25'                  -
) ;


