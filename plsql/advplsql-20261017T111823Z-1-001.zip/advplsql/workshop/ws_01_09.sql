EXPLAIN PLAN FOR
SELECT cust_last_name                        
FROM   customers
WHERE  cust_id LIKE '7%'
/
