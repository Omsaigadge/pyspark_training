
set autotrace traceonly explain

SELECT   t.week_ending_day
,        t.calendar_year
,        p.prod_subcategory
,        sum(c.unit_cost) AS dollars
FROM     costs c, times t, products p
WHERE    c.time_id = t.time_id
AND      c.prod_id = p.prod_id
AND      t.calendar_year = '1999'
GROUP BY t.week_ending_day, t.calendar_year
,        p.prod_subcategory
HAVING   sum(c.unit_cost) > 10000;



