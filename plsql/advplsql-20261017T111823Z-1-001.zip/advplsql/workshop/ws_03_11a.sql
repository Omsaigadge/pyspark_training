SELECT cust_first_name
   FROM   customers c
   WHERE cust_first_name = 'Victoria' 
/  
