set feedback off


SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);

set feedback on
