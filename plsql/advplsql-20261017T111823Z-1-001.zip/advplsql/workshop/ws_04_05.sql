SELECT *                                
FROM promotions_iot
WHERE promo_subcategory = 'online discount'
/
