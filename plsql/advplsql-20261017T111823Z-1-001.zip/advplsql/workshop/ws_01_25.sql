EXPLAIN PLAN FOR
SELECT cust_city                        
,      AVG(cust_credit_limit)
FROM   customers
GROUP  BY cust_city
/
