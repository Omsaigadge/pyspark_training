CREATE table emp AS SELECT * FROM employees
/

DELETE FROM emp
/
     
