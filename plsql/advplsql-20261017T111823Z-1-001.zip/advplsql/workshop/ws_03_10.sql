SELECT  country_id, count(*)  
FROM   customers
GROUP  BY  country_id
/
