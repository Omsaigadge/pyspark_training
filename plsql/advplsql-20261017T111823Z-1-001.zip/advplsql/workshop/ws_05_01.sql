CREATE OR REPLACE VIEW v_sales_detail  
  AS
   SELECT sa.prod_id
   ,      pr.prod_name
   ,      pr.supplier_id
   ,      pr.prod_status
   ,      sa.amount_sold
   ,      to_char(sa.time_id, 'YYYY-MON-DD') date_sold
   FROM   sales sa
   ,      products pr
   WHERE  pr.prod_id = sa.prod_id(+)
/
