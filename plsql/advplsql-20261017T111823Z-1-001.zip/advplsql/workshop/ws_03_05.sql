SELECT  c.*                  
FROM   customers c
WHERE  c.cust_year_of_birth   = 1953
AND   c.cust_credit_limit  = 10000
/
