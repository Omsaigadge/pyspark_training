DROP TABLE test_sales;
DROP TABLE test_promotions;
DROP TABLE test_customers;
DROP TABLE test_countries;

CREATE table test_sales as select * from sales;


CREATE TABLE test_promotions AS SELECT * FROM promotions;
CREATE INDEX t_promo_id_idx ON TEST_PROMOTIONS(promo_id); 

ALTER TABLE test_promotions MODIFY promo_id PRIMARY KEY USING INDEX t_promo_id_idx; 

CREATE TABLE test_customers AS SELECT * FROM customers;
CREATE INDEX t_cust_id_idx ON TEST_CUSTOMERS(cust_id); 

ALTER TABLE test_customers MODIFY cust_id PRIMARY KEY USING INDEX t_cust_id_idx; 

CREATE TABLE test_countries AS SELECT * FROM countries;
CREATE INDEX t_country_id_idx ON TEST_COUNTRIES(country_id); 

ALTER TABLE test_countries MODIFY country_id PRIMARY KEY USING INDEX t_country_id_idx; 


UPDATE test_customers SET cust_credit_limit = 1000 WHERE ROWNUM <= 15000;
