select cust_first_name, cust_last_name, cust_credit_limit
FROM customers
WHERE cust_id =100;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =153;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =176;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =198;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =345;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =560;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =789;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =10023;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =5678;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =6543;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =1114;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =2312;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =5689;
SELECT cust_first_name, cust_last_name, cust_credit_limit 
FROM customers
WHERE cust_id =10078;
