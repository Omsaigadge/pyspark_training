SELECT /*+ &hint */ COUNT(*)
FROM sales s
WHERE EXISTS (SELECT 'x'
              FROM customers c
              WHERE s.cust_id = c.cust_id) 
/
