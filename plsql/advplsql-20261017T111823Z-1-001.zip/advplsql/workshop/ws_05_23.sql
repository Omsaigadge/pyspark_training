
set echo on

rem now without the typo:

SELECT /*+ REWRITE_OR_ERROR */
       prod_id
,      avg(amount_sold)
FROM   sales
WHERE  channel_id = 9
GROUP  BY prod_id;
