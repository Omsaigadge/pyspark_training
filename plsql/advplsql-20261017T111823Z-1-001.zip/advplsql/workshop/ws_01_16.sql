EXPLAIN PLAN FOR
SELECT MAX(cust_credit_limit)             
FROM   customers
/
