
set echo on

CONNECT sh/sh

DROP MATERIALIZED VIEW my_mv;


CREATE MATERIALIZED VIEW my_mv
   BUILD IMMEDIATE
   ENABLE QUERY REWRITE
AS SELECT prod_id
   ,      avg(amount_sold) as avg_amount
   FROM   sales
   WHERE  channel_id = 9
   GROUP  by prod_id;

rem gather statistics for the MV...

EXECUTE DBMS_STATS.GATHER_TABLE_STATS(USER,'MY_MV');

SELECT * FROM my_mv;