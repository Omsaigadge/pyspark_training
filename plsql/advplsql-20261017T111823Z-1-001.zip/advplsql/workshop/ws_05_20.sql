SELECT mvname, capability_name, possible
FROM mv_capabilities_table
WHERE statement_id = '678' ORDER BY seq;
