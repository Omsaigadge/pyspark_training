SELECT employee_id, last_name
FROM   employees e1
WHERE  e1.salary >
       (select avg(salary)
        from employees e2
        where e1.department_id = e2.department_id
        group by e2.department_id)
/
