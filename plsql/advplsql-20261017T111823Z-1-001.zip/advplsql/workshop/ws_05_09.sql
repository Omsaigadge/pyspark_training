CREATE OR REPLACE VIEW v_avg_credit_limit    
AS SELECT    country_id
,            avg(cust_credit_limit)  AVG_CREDIT
FROM customers
GROUP BY country_id
/
