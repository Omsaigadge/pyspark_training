EXPLAIN PLAN FOR
SELECT cust_email                        
FROM   customers
WHERE  cust_email IS NULL
/
