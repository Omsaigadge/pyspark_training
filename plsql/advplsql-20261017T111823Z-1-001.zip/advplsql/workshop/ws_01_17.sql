EXPLAIN PLAN FOR
SELECT MAX(cust_credit_limit+1000)          
FROM   customers
/
