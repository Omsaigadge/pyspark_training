ALTER SESSION SET optimizer_dynamic_sampling=10
/
