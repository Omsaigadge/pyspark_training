



accept table_name  -
       prompt 'on which table : '







SELECT last_analyzed analyzed, sample_size, monitoring,
        table_name
FROM user_tables 
WHERE table_name = upper('&table_name');





undef  TABLE_NAME
