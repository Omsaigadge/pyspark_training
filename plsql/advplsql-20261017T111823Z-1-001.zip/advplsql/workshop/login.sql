REM ======================================
REM COL[UMN] commands
REM ======================================
col dummy new_value    index_name

col name               format a32
col segment_name       format a20
col table_name         format a20
col column_name        format a20
col index_name         format a30
col index_type         format a10
col constraint_name    format a20
col num_distinct       format 999999
col update_comment     format a20 word

--  for the SHOW SGA/PARAMETER commands:

col name_col_plus_show_sga    format a24
col name_col_plus_show_param  format a40 -
                       heading name
col value_col_plus_show_param format a35 -
                       heading value

-- for the AUTOTRACE setting:

col id_plus_exp          format 90 head i
col parent_id_plus_exp   format 90 head p
col plan_plus_exp        format a80
col other_plus_exp       format a44
col other_tag_plus_exp   format a29
col object_node_plus_exp format a8

REM ======================================
REM SET commands
REM ======================================
set describe  depth 2
set echo      off
set editfile  D:\Tmp\buffer.sql
set feedback  40
set linesize  120
set long      999
set numwidth  8
set pagesize  36
set pause     "[Enter]..." pause off
set tab       off
set trimout   on
set trimspool on
set verify    off
set wrap      on

REM ======================================
REM DEFINE commands
REM ======================================
def 1=employees
def table_name=employees
def column_name=first_name
def buckets=1
def sc=';'

REM ======================================
REM miscellaneous
REM ======================================

