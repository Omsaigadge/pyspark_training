CREATE  TABLE sales_temp
(cust_id NUMBER,
 amount_sold NUMBER)
    
/

INSERT INTO sales_temp select cust_id, amount_sold
FROM sales WHERE rownum <= 10
/
