EXPLAIN PLAN FOR
SELECT cust_first_name                  
,      cust_last_name
,      cust_city 
FROM   customers
WHERE  cust_city = 'Paris'
ORDER  BY cust_id
/
