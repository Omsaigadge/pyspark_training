REM  
REM  script ATTOX.SQL
REM  =====================================
set autotrace traceonly explain