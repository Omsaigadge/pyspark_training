SELECT e1.employee_id, e1.last_name
FROM   employees e1
,      (select avg(salary) avg_sal, department_id
        from   employees 
        group by department_id) a
WHERE  e1.salary > a.avg_sal
AND    e1.department_id = a.department_id
/
