EXPLAIN PLAN FOR
SELECT cust_city                        
,      avg(cust_credit_limit)
FROM   customers
GROUP  BY cust_city
HAVING cust_city = 'Paris'
/
