SELECT c.cust_gender, c.cust_marital_status, SUM(quantity_sold), 
SUM(amount_sold) 
FROM test_promotions p,test_sales s,test_customers c 
WHERE p.promo_id=s.promo_id 
  AND promo_name='NO PROMOTION #' 
  AND s.cust_id=c.cust_id 
GROUP BY c.cust_gender, c.cust_marital_status;
