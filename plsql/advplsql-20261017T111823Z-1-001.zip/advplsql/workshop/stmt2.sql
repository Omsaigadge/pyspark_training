SELECT max(cust_credit_limit)
FROM test_customers
WHERE cust_city ='Paris';
