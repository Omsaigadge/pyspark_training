SELECT * FROM products WHERE prod_status = 'obsolete'
/
