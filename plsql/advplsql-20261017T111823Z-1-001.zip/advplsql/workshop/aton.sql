REM  
REM  script ATON.SQL
REM  =====================================
SET AUTOTRACE ON
