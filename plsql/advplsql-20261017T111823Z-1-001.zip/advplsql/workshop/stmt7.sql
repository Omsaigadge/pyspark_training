SELECT cust_last_name, cust_first_name
FROM test_customers
WHERE UPPER(cust_last_name)LIKE  'K%';
